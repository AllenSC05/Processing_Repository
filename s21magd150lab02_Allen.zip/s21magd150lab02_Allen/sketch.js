//s21magd150lab02_Allen
//4 different colors
//use all 3 modes of representing color
//use at least one of these 3 shapes: bezier curve, Arc, Quad, Triangle, Shape, Contour.

function setup() {
  createCanvas(800, 800);
  colorMode(HSB,360,100,100,100);
  background(0,0,5);
  
  
}

function draw() {


  stroke(140, 112, 79);
  strokeWeight(10)
  noFill()
  bezier(200,200,600,200,600,600,600,600)
  noStroke();
  
  fill(color('#F25A38'));
  beginShape()
  vertex(200,400);
  vertex(250,275);
  vertex(400,200);
  vertex(550,275);
  vertex(600,400);
  vertex(550,550);
  vertex(400,600);
  vertex(250,550);
  endShape();
  
  colorMode(HSL);
  fill(0,0,5);
  triangle(525,250,525,300,600,290)
  
  fill(color('#A63126'));
  ellipse(450,280,10);
  ellipse(500,440,90);
  ellipse(330,490,75);
  ellipse(300,325,25);
  
  colorMode(RGB)
  stroke(140, 112, 79);
  strokeWeight(10)
  noFill()
  bezier(200,200,200,600,600,600,600,600)
  noStroke();

  
}