//instantiate and define variables as needed.

let channel = 1;
let clickerUp;
let clickerDown;
let ellipseX = 65;
let ellipseY = 740;
let ellipseSize = 75;
let fillVar = 50;
let ballX = 0.5;
let off = true;

//turn power button red/green (off/on),  on start up initialize as red.
let buttonOncolor = ('green');
let buttonOffcolor = ('red');
let buttonColor = ('red');

//for creating smooth randomness.
let nGen = 0.0;
let nPlus = 0;
let nPlusmapped;





function setup() {  
  
  createCanvas(800,800); 
  rectMode(CENTER);
  
  clickerUp = createButton ('up');
  clickerUp.position (550,700);
  clickerUp.size(100,80);
  clickerUp.mousePressed(channelSwitchUp);
  
  clickerDown = createButton ('down');
  clickerDown.position(650,700);
  clickerDown.size(100,80);
  clickerDown.mousePressed (channelSwitchDown);
  
}

function draw() {
  
  let nGen = noise(nPlus);
  nPlus += 0.5;
  plusMapped = map (nGen, 0, 1, 100, 700);
  

  // TV screen
  fill (fillVar);
  stroke(0);
  strokeWeight(10);
  rect(width/2,height/2.2, 600,600,10); 

 
  if (channel == 1){
    channelOne();
  } else if (channel == 2){
    channelTwo();
  }
  
  //power button
  
  fill(color(buttonColor));
  strokeWeight(2);
  stroke(25)
  ellipse(ellipseX,ellipseY,ellipseSize);
  
  
 
}


function mousePressed(){
  
 let x = mouseX;
 let y = mouseY;
  
  if (dist(x,y,ellipseX,ellipseY) <= ellipseSize/2){
      
      circleClicked();
      
      }
  

}

function circleClicked(){
  
  if (off){
    fillVar = 255;
    buttonColor = buttonOncolor;
    off = false;
  } else if (off == false){
    
    fillVar = 50;
    buttonColor = buttonOffcolor;
    off = true;
    
  }
  
  
}

function channelOne (){
  
  if (off == false ){
  stroke(0);
  strokeWeight(5);
  strokeCap(SQUARE);
  line (100,plusMapped, 700, plusMapped);
  noStroke();
  }
  
}

function channelTwo (){
  
  if (off == false ){

    ellipse(map(sin(ballX),-1,1,300,500),height/2,200);
    ballX += 0.1;
    
    print ( sin(ballX))
  }
  
}

function channelSwitchUp(){
  channel = 2
}
function channelSwitchDown(){
  channel = 1;
}