class tree {
  
  
  constructor(){
    
    
  }
  
  
  
  display(x,y){

    this.x = x;
    this.y = y;
   
    // create 3 ellipses to represent leaves, and a rectangle to represent the tree trunk
    
    push();
    translate(x,y);
    
    fill(44, 27, 8);
    stroke(34, 20, 2);
    strokeWeight(2);
    rect(7,75,40,80);
    
    
    fill(color('green'));
    strokeWeight(3);
    stroke(14, 70, 0);
    ellipse(0,50,75);
    ellipse(50,50,75);
    ellipse(25,15,75);
    
    
    pop();
  }
  
}