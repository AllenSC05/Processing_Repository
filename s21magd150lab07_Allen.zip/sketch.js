let treeArray = [];
let increment = 0;

function setup() {
  
  //Create the sky and the ground.
  noStroke();
  createCanvas(800, 800);
  background(12, 64, 196);
  fill(12, 64, 10);
  rect(0,height/2,width,height/2);
  
  //distribute blades of grass across the ground.
  for (let i = 0; i  < 200; i++){
    stroke(12, 24, 10);
    strokeWeight(0.5);
    let grassX = random(0, width);
    let grassY = random( height/2, height);
    line(grassX,grassY,grassX, grassY - 5);
    
    }

  //in a more orderly fashion, distribute trees across our lanscap so they don't overlap oddly.
  for (let i = 0; i  < 25; i++){
    N = noise(increment);
    nMapped = map(N,0.0, 1.0 ,400,800);
    
    tree[i] = new tree();
    tree[i].display(random(0,width), (height/2 - 100) + increment);
    increment += 20;
    }

  
}                 
      
function draw() {
  
  for( tree[i] = 0; tree[i] < 25; tree[i] ++) {
      
    tree[i.sway]
      
      }

}


