//  a metranome set at a tempo of 60 BPM.  it counts 4 beats in a bar and counts 4 bars before reseting. 

//seconds() communicates with the computer clock.
//it's used to ensure that the timer is steady and not thrown off by changes or hiccups in frame rate.


let startClock = 0;
let time;
let beat;
let measure = 1;
let resetMeasure = false;
let bubblePop = true
let bubbleX;
let bubbleY;
let bubbleSize;
let a;
let b;

function setup() {
  
  createCanvas(400, 400);
  frameRate(60);  
  time = second();
  
}


function draw() {

  background(50,100,200);

  
  if (second() != time){
  time = second();
  startClock ++;
  bubblePop = true;
  }

  beat = startClock % 4 + 1;
  
  if(beat == 4){
    Reset();
  }
  
  if (beat == 1 && resetMeasure == true){
    measure = (measure % 4) + 1;
    resetMeasure = false;
    
  }
  

if(beat == 1){
 bubbleX = width/4.5; bubbleY= height/4.5;
}else if(beat == 2){
  bubbleX = width - width/4.5; bubbleY = height/4.5;
} else if (beat == 3){
  bubbleX = width/4.5; bubbleY = height - height/4.5;
} else if(beat == 4){
  bubbleX = width - width/4.5; bubbleY = height - height/4.5;
}
  

noStroke();
fill(200,200,255,150);
ellipse(bubbleX,bubbleY, map(measure,1,4,50,200));


print(beat, measure);
  
}


function Reset(){
  resetMeasure = true; 
}
